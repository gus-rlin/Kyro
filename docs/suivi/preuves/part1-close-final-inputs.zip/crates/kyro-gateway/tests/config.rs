use kyro_domain::{Environment, Error};
use kyro_gateway::{DisabledReason, GatewayConfig};

const SYNTHETIC_REGISTRY: &str = include_str!("../../../config/models.synthetic.json");

#[test]
fn synthetic_registry_requires_development_opt_in_and_server_secret() {
    let without_secret = GatewayConfig::from_registry_json(
        SYNTHETIC_REGISTRY.as_bytes(),
        Environment::Development,
        true,
        None,
    )
    .expect("trusted synthetic registry parses");
    let row = without_secret.registry().remove(0);
    assert!(!row.enabled);
    assert_eq!(row.disabled_reason, Some(DisabledReason::MissingSecret));

    let with_secret = GatewayConfig::from_registry_json(
        SYNTHETIC_REGISTRY.as_bytes(),
        Environment::Development,
        true,
        Some("invented-test-token"),
    )
    .expect("synthetic registry with a server secret parses");
    assert!(with_secret.registry()[0].enabled);
    assert!(!format!("{with_secret:?}").contains("invented-test-token"));

    assert!(matches!(
        GatewayConfig::from_registry_json(
            SYNTHETIC_REGISTRY.as_bytes(),
            Environment::Production,
            false,
            Some("invented-test-token"),
        ),
        Err(Error::Invalid(_))
    ));
}

#[test]
fn admission_registry_is_eligible_without_enabling_execution() {
    let config = GatewayConfig::for_admission_from_registry_json(
        SYNTHETIC_REGISTRY.as_bytes(),
        Environment::Development,
        true,
    )
    .expect("admission registry parses without any secret");
    let model = config.registry().remove(0);
    assert!(model.admissible);
    assert!(!model.enabled);
    assert_eq!(model.disabled_reason, None);
}

#[test]
fn registry_rejects_non_loopback_pins_and_host_confusion() {
    let private_pin = SYNTHETIC_REGISTRY.replace("127.0.0.1:4318", "10.0.0.8:4318");
    assert!(matches!(
        GatewayConfig::from_registry_json(
            private_pin.as_bytes(),
            Environment::Development,
            true,
            Some("invented-test-token"),
        ),
        Err(Error::Invalid(_))
    ));

    let mismatched_host = SYNTHETIC_REGISTRY.replace(
        "\"allowed_host\": \"127.0.0.1\"",
        "\"allowed_host\": \"attacker.invalid\"",
    );
    assert!(matches!(
        GatewayConfig::from_registry_json(
            mismatched_host.as_bytes(),
            Environment::Development,
            true,
            Some("invented-test-token"),
        ),
        Err(Error::Invalid(_))
    ));
}
